--
-- Database: `barter`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori_posting`
--

CREATE TABLE `kategori_posting` (
  `id_kategori_posting` int(11) NOT NULL,
  `slug_kategori_posting` varchar(200) NOT NULL,
  `nama_kategori_posting` varchar(200) NOT NULL,
  `keterangan` text NOT NULL,
  `urutan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori_posting`
--

INSERT INTO `kategori_posting` (`id_kategori_posting`, `slug_kategori_posting`, `nama_kategori_posting`, `keterangan`, `urutan`) VALUES
(3, 'otomotif', 'Otomotif', 'otomotif', 1),
(4, 'mainan', 'Mainan', 'mainan', 2),
(7, 'pakaian', 'Pakaian', 'pakaian', 3),
(8, 'elektronik', 'Elektronik', 'elektronik', 4),
(9, 'interior', 'Interior', 'interior', 5),
(10, 'makanan', 'Makanan', 'makanan', 6),
(12, 'tas', 'Tas', 'Tas', 8),
(13, 'sepatu', 'Sepatu', 'sepatu', 7),
(14, 'lainnya', 'Lainnya', 'dll', 9);

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(11) NOT NULL,
  `from` varchar(100) NOT NULL,
  `to` varchar(100) NOT NULL,
  `nama_barang1` varchar(200) NOT NULL,
  `id_posting` int(11) NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar1` varchar(255) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `from`, `to`, `nama_barang1`, `id_posting`, `deskripsi`, `gambar1`, `tanggal`) VALUES
(3, '17', '14', 'Bola', 44, '<p>bagaimana jika di barterkan dengan bola ini gan? jika berminat hubungi nomor ane 8912242424</p>', 'bola.jpg', '2016-09-21 16:32:03');

-- --------------------------------------------------------

--
-- Table structure for table `posting`
--

CREATE TABLE `posting` (
  `id_posting` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_kategori_posting` int(11) NOT NULL,
  `slug_posting` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `kota` varchar(255) NOT NULL,
  `status_posting` varchar(20) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posting`
--

INSERT INTO `posting` (`id_posting`, `id_user`, `id_kategori_posting`, `slug_posting`, `judul`, `isi`, `kota`, `status_posting`, `gambar`, `tanggal`) VALUES
(44, 14, 3, '1-samyang', 'Samyang', '<p>Misi gan numpang barter mie samyang, tawar aja barang agan jika berminat</p>', 'Jakarta Utara', 'Publish', 'thumb-3070052907_cxIE1BRf_s-l1000_800x5732.jpg', '2016-09-22 17:10:44'),
(45, 17, 4, '45-mainan-bonkar-pasang-truk', 'Mainan Bonkar Pasang Truk', '<p>Numpang barter mainan mobil-mobilan untuk anak masih mulus tawar aja dengan barang agan siapa tau cocok.</p>\r\n<p>makasih gan</p>', 'Jakarta Pusat', 'Publish', 'mainan-bongkar-pasang-truk-molen.jpg', '2016-09-21 16:25:43'),
(46, 17, 9, '46-lampu-belajar-doraemon', 'Lampu Belajar Doraemon', '<p>numpang barter gan , tawar aja dengan barang yang agan punya</p>', 'Jakarta Timur', 'Publish', 'Lampu-Emergency-Doraemon-Face-Body.jpg', '2016-09-21 16:29:49'),
(47, 14, 3, '47-handphone-nokia-jadul', 'Action Figure Dota 2', '<p>Numpang barter nih gan tawar aja dengan barang agan makasih&nbsp;</p>', 'Jakarta Barat', 'Publish', '12142144_698224390278098_2112090704_n2.jpg', '2016-09-22 17:10:55'),
(48, 14, 7, '48-baju-distro', 'Baju Distro', '<p>Baju baru dipakai sekali nih gan barter dong sama barang yang agan punya&nbsp;</p>', 'Jakarta Barat', 'Publish', '13437326_255513948153193_1020209140_n.jpg', '2016-09-22 03:06:06'),
(49, 14, 4, '49-bola', 'Bola ', '<p>Numpang barter barang gak dipake nih</p>', 'Jakarta Barat', 'Publish', 'bola1.jpg', '2016-09-22 05:00:00'),
(50, 13, 3, '50-hape-nokia-jadul', 'Hape Nokia Jadul', '<p>Numpang barter hp nokia jadul gan</p>', 'Jakarta Barat', 'Publish', 'aplikasi_nokia_6600.jpg', '2016-09-22 17:17:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(64) NOT NULL,
  `no_telp` varchar(50) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `akses_level` varchar(20) NOT NULL,
  `gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `username`, `password`, `no_telp`, `tanggal`, `akses_level`, `gambar`) VALUES
(13, 'Ahmad Fauzan', 'fauzaine@gmail.com', 'fauzan', '7c4a8d09ca3762af61e59520943dc26494f8941b', '45435454', '2016-08-31 12:03:35', 'Admin', 'Howl_full_1933422.jpg'),
(14, 'adam rahmat', 'adam@gmail.com', 'adam', '7c4a8d09ca3762af61e59520943dc26494f8941b', '2131213', '2016-09-22 17:12:43', 'User', 'MTE5NDg0MDU1MTUzMTE2Njg3.jpg'),
(15, 'Rizky Agung', 'R17Agung@gmail.com', 'agung', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', '2016-08-28 13:02:39', 'Blocked', 'jigsaw_ransomware_logo-100655592-large1.jpg'),
(16, 'ryan apriansyah', 'raryanapriansyah@gmail.com', 'ryzulla', '7c4a8d09ca3762af61e59520943dc26494f8941b', '089223113', '2016-08-20 15:19:13', 'Admin', '12142144_698224390278098_2112090704_n1.jpg'),
(17, 'irmanv ', 'irmanjuliansyah@gmail.com', 'irman', 'dd5fef9c1c1da1394d6d34b248c51be2ad740840', '675656757', '2016-09-09 15:46:39', 'User', 'MTE5NDg0MDU1MTUzMTE2Njg31.jpg'),
(18, 'rizky a p', 'royriki1996@gmail.com', 'bravo', '8cb2237d0679ca88db6464eac60da96345513964', '01238434343', '2016-08-29 14:21:55', 'User', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kategori_posting`
--
ALTER TABLE `kategori_posting`
  ADD PRIMARY KEY (`id_kategori_posting`),
  ADD UNIQUE KEY `slug_kategori_posting` (`slug_kategori_posting`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `posting`
--
ALTER TABLE `posting`
  ADD PRIMARY KEY (`id_posting`),
  ADD UNIQUE KEY `slug_berita` (`slug_posting`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kategori_posting`
--
ALTER TABLE `kategori_posting`
  MODIFY `id_kategori_posting` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `posting`
--
ALTER TABLE `posting`
  MODIFY `id_posting` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
